import { authHeaders } from '../lib/api';
import { useState, useEffect, useRef } from 'react';
import Discussions from './Discussions';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { notaDinScor } from '../lib/nota';

// ─── Helpers ─────────────────────────────────────────────────────────────────

// Scroll robust către un card: așteaptă apariția în DOM, apoi re-centrează
// repetat câteva sute de ms, ca să compenseze deplasările de layout cauzate
// de încărcarea asincronă a conținutului (important mai ales pe mobil).
export function scrollToCard(cardId, { initialDelay = 150 } = {}) {
  if (!cardId) return () => {};
  let cancelled = false;
  const timers = [];
  let findAttempts = 0;
  let recenters = 0;

  function recenter() {
    if (cancelled) return;
    const el = document.getElementById(`card-${cardId}`);
    if (el) el.scrollIntoView({ block: 'center' });
  }

  function tick() {
    if (cancelled) return;
    const el = document.getElementById(`card-${cardId}`);
    if (el) {
      recenter();
      // Re-centrăm de mai multe ori pe măsură ce conținutul se așază
      if (recenters < 12) {
        recenters++;
        timers.push(setTimeout(tick, 250));
      }
    } else if (findAttempts < 60) {
      findAttempts++;
      timers.push(setTimeout(tick, 100));
    }
  }

  timers.push(setTimeout(tick, initialDelay));
  return () => { cancelled = true; timers.forEach(clearTimeout); };
}

function getOriginalFilename(url) {
  if (!url) return null;
  try {
    const decoded = decodeURIComponent(url);
    const parts = decoded.split('/');
    const filename = parts[parts.length - 1];
    // Remove timestamp prefix (e.g. "1776193195857_")
    return filename.replace(/^\d+_/, '');
  } catch {
    return null;
  }
}

// ─── Preview prima pagină ────────────────────────────────────────────────────
function PreviewModal({ item, onClose }) {
  const [imgUrl, setImgUrl] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        await ensurePdfJs();

        // Încearcă URL direct (pentru bucket public / fișiere gratuite)
        let url = item.file_url;
        // Pentru fișiere non-free, mergi direct la signed URL fără fetch inițial
        let resp = item.is_free ? await fetch(url) : { status: 403 };

        if (resp.status === 403 || resp.status === 400 || resp.status === 401) {
          // Bucket privat — obținem signed URL pentru preview
          const r = await fetch('/api/get-preview-url', {
            method: 'POST',
            headers: await authHeaders(),
            body: JSON.stringify({ contentId: item.id }),
          });
          const d = await r.json();
          console.log('Preview URL response:', r.status, d);
          if (!r.ok || !d.url) {
            console.error('Preview error:', d);
            setError(true);
            setLoading(false);
            return;
          }
          url = d.url;
          resp = await fetch(url);
          console.log('PDF fetch status:', resp.status);
        }

        if (!resp.ok) throw new Error();
        const buf = await resp.arrayBuffer();
        const pdf = await window.pdfjsLib.getDocument({ data: buf }).promise;
        const page = await pdf.getPage(1);
        const scale = window.innerWidth < 600 ? 1.2 : 1.8;
        const vp = page.getViewport({ scale });
        const canvas = document.createElement('canvas');
        canvas.width = vp.width; canvas.height = vp.height;
        await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;
        setImgUrl(canvas.toDataURL('image/jpeg', 0.92));
      } catch {
        setError(true);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)',
        zIndex: 9999, display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', padding: 16,
      }}
    >
      <div onClick={e => e.stopPropagation()} style={{ position: 'relative', maxWidth: '100%', maxHeight: '90vh' }}>
        {/* Header */}
        <div style={{
          background: 'var(--navy)', padding: '10px 16px', borderRadius: '10px 10px 0 0',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <span style={{ color: '#fff', fontWeight: 600, fontSize: '0.88rem' }}>
            👁 Preview — {item.title}
          </span>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <span style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)' }}>
              Prima pagină • Abonează-te pentru a descărca
            </span>
            <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#fff', cursor: 'pointer', fontSize: '1.2rem', lineHeight: 1 }}>✕</button>
          </div>
        </div>

        {/* Imagine */}
        <div style={{
          background: '#fff', borderRadius: '0 0 10px 10px', overflow: 'hidden',
          maxHeight: 'calc(90vh - 50px)', overflowY: 'auto',
          userSelect: 'none', WebkitUserSelect: 'none',
        }}
          onContextMenu={e => e.preventDefault()}
        >
          {loading && (
            <div style={{ padding: 60, textAlign: 'center', color: '#999' }}>
              Se generează previzualizarea...
            </div>
          )}
          {error === 'login_required' && (
            <div style={{ padding: 40, textAlign: 'center' }}>
              <div style={{ fontSize:'2rem', marginBottom:12 }}>🔒</div>
              <p style={{ color:'#5a6170', marginBottom:16, fontSize:'0.9rem' }}>Autentifică-te pentru a vedea previzualizarea.</p>
              <a href="/autentificare" style={{ padding:'8px 20px', background:'var(--navy)', color:'#fff', borderRadius:8, textDecoration:'none', fontWeight:600, fontSize:'0.88rem' }}>Autentifică-te</a>
            </div>
          )}
          {error === 'premium_required' && (
            <div style={{ padding: 40, textAlign: 'center' }}>
              <div style={{ fontSize:'2rem', marginBottom:12 }}>⭐</div>
              <p style={{ color:'#5a6170', marginBottom:16, fontSize:'0.9rem' }}>Abonează-te pentru a vedea previzualizarea completă.</p>
              <a href="/preturi" style={{ padding:'8px 20px', background:'var(--gold)', color:'var(--navy-dark)', borderRadius:8, textDecoration:'none', fontWeight:600, fontSize:'0.88rem' }}>Vezi prețuri</a>
            </div>
          )}
          {error === true && (
            <div style={{ padding: 40, textAlign: 'center', color: '#e53935' }}>
              Nu s-a putut genera previzualizarea.
            </div>
          )}
          {imgUrl && (
            <img
              src={imgUrl}
              alt="Preview"
              draggable={false}
              style={{ display: 'block', maxWidth: '100%', pointerEvents: 'none' }}
              onContextMenu={e => e.preventDefault()}
            />
          )}
        </div>
      </div>
      <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.75rem', marginTop: 12 }}>
        Apasă în afara imaginii pentru a închide
      </p>
    </div>
  );
}

async function ensurePdfJs() {
  if (window.pdfjsLib) return;
  await new Promise((ok, err) => {
    const s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
    s.onload = ok; s.onerror = err;
    document.head.appendChild(s);
  });
  window.pdfjsLib.GlobalWorkerOptions.workerSrc =
    'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
}

// ─── Badge progres ────────────────────────────────────────────────────────────
function ProgressBadge({ progress }) {
  if (!progress) return null;
  const pct = Math.round((progress.score / progress.max_score) * 100);
  const nota = notaDinScor(progress.score, progress.max_score); // cu 10 p din oficiu
  const color = pct >= 80 ? '#2e7d32' : pct >= 50 ? '#e65100' : '#c62828';
  const bg   = pct >= 80 ? '#e8f5e9' : pct >= 50 ? '#fff3e0' : '#fce4ec';
  return (
    <div style={{ display:'flex', alignItems:'center', gap:5, flexShrink:0 }}>
      <span style={{
        display:'inline-flex', alignItems:'center', gap:4,
        padding:'4px 10px', borderRadius:20, fontSize:'0.73rem', fontWeight:700,
        background:bg, color,
      }}>
        ✓ {pct}%{nota != null ? ` · nota ${nota}` : ''}
      </span>
      <span style={{ fontSize:'0.69rem', color:'var(--text-muted)', whiteSpace:'nowrap' }}>
        {progress.score}/{progress.max_score} pct
      </span>
    </div>
  );
}

// ─── Card item ────────────────────────────────────────────────────────────────
export function ContentCard({ item, isPremium, user, progress, _overrideSrcDoc, forceTab }) {
  const canAccess = item.is_free || isPremium;
  const navigate = useNavigate();
  const [showPreview, setShowPreview] = useState(false);

  const typeConfig = {
    pdf:         { icon: '📄', bg: '#e3f2fd', actionLabel: 'Deschide / Descarcă' },
    interactive: { icon: _overrideSrcDoc ? '📖' : '🧩', bg: _overrideSrcDoc ? '#e8f5e9' : '#f3e5f5', actionLabel: 'Deschide' },
    manual:      { icon: '📖', bg: '#e8f5e9', actionLabel: 'Citește' },
  };
  const cfg = typeConfig[item.content_type] || typeConfig.pdf;

  const isPdf = item.content_type === 'pdf';
  const isInteractive = item.content_type === 'interactive';

  // Tab-ul la care ne întoarcem: forceTab (dacă e dat de pagina-părinte,
  // ex. un bloc interactive aflat în tab-ul PDF) sau tipul conținutului.
  const returnTab = forceTab || item.content_type;

  function handlePdfOpen() {
    navigate('/pdf-viewer', { state: { item, returnTo: window.location.pathname, scrollToCardId: item.id, returnTab, returnSubcategory: item.subcategory, returnContentType: item.content_type } });
  }

  function handleInteractive(e) {
    e.preventDefault();
    navigate('/exercitiu', { state: { item, srcDoc: _overrideSrcDoc, returnTo: window.location.pathname, scrollToCardId: item.id, returnTab, returnSubcategory: item.subcategory, returnContentType: item.content_type } });
  }

  return (
    <div
      id={`card-${item.id}`}
      style={{
        display: 'flex', flexDirection: 'column',
        padding: '14px 16px', background: '#fff', borderRadius: 10,
        border: '1.5px solid #eef0f4', marginBottom: 8,
        transition: 'box-shadow 0.2s', gap: 10,
      }}
      onMouseEnter={e => e.currentTarget.style.boxShadow = '0 2px 12px rgba(15,43,68,0.09)'}
      onMouseLeave={e => e.currentTarget.style.boxShadow = 'none'}
    >
      {/* Rând 1: icon + titlu */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, minWidth: 0 }}>
        <div style={{
          width: 36, height: 36, borderRadius: 8, flexShrink: 0,
          background: cfg.bg, display: 'flex', alignItems: 'center',
          justifyContent: 'center', fontSize: '1.1rem',
          opacity: canAccess ? 1 : 0.5,
        }}>
          {cfg.icon}
        </div>
        <div style={{ minWidth: 0 }}>
          <div style={{
            fontWeight: 600, color: canAccess ? 'var(--navy)' : 'var(--text-muted)',
            fontSize: '0.92rem',
          }}>
            {item.title}
          </div>
          {item.description && (
            <div style={{ fontSize: '0.76rem', color: 'var(--text-muted)', marginTop: 2 }}>
              {item.description}
            </div>
          )}
          {isPdf && getOriginalFilename(item.file_url) && (
            <div className="filename-original">
              {getOriginalFilename(item.file_url)}
            </div>
          )}
        </div>
      </div>

      {/* Rând 2: progres + badge + buton */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
        {isInteractive && user && progress && (
          <ProgressBadge progress={progress} />
        )}

        <span style={{
          padding: '3px 10px', borderRadius: 20, fontSize: '0.72rem', fontWeight: 700,
          background: item.is_free ? '#e8f5e9' : '#fff3e0',
          color: item.is_free ? '#2e7d32' : '#e65100',
        }}>
          {item.is_free ? 'Gratuit' : 'Premium'}
        </span>

        <div style={{ marginLeft: 'auto' }}>
          {canAccess ? (
            isPdf ? (
              // PDF normal → PDFViewer cu blob URL
              <button
                onClick={handlePdfOpen}
                disabled={!item.file_url}
                style={{
                  padding: '7px 18px', borderRadius: 7, fontWeight: 600, fontSize: '0.85rem',
                  background: item.file_url ? 'var(--navy)' : '#ccc',
                  color: '#fff', border: 'none', cursor: 'pointer', whiteSpace: 'nowrap',
                }}
              >
                {cfg.actionLabel}
              </button>
            ) : (
              <button
                onClick={handleInteractive}
                disabled={!item.file_url && !_overrideSrcDoc}
                style={{
                  padding: '7px 18px', borderRadius: 7, fontWeight: 600, fontSize: '0.85rem',
                  background: 'var(--navy)', color: '#fff', border: 'none', cursor: 'pointer',
                  opacity: (!item.file_url && !_overrideSrcDoc) ? 0.4 : 1,
                  whiteSpace: 'nowrap',
                }}
              >
                {cfg.actionLabel}
              </button>
            )
          ) : !user ? (
            <div style={{ display:'flex', gap:6, flexWrap:'wrap', alignItems:'center' }}>
              {isPdf && item.file_url && (
                <button onClick={() => setShowPreview(true)}
                  style={{ padding:'7px 12px', borderRadius:7, fontWeight:600, fontSize:'0.8rem', background:'#f0f4f8', color:'var(--navy)', border:'1.5px solid #dde1e8', cursor:'pointer', whiteSpace:'nowrap' }}>
                  👁 Preview
                </button>
              )}
              <Link to="/autentificare" style={{ padding:'7px 14px', borderRadius:7, fontWeight:600, fontSize:'0.83rem', background:'#f0f4f8', color:'var(--navy)', border:'1.5px solid #dde1e8', textDecoration:'none', whiteSpace:'nowrap', display:'inline-block' }}>
                🔒 Autentifică-te
              </Link>
            </div>
          ) : (
            <div style={{ display:'flex', gap:6, flexWrap:'wrap', alignItems:'center' }}>
              {isPdf && item.file_url && (
                <button onClick={() => setShowPreview(true)}
                  style={{ padding:'7px 12px', borderRadius:7, fontWeight:600, fontSize:'0.8rem', background:'#f0f4f8', color:'var(--navy)', border:'1.5px solid #dde1e8', cursor:'pointer', whiteSpace:'nowrap' }}>
                  👁 Preview
                </button>
              )}
              <Link to="/preturi" style={{ padding:'7px 14px', borderRadius:7, fontWeight:600, fontSize:'0.83rem', background:'var(--gold)', color:'var(--navy-dark)', textDecoration:'none', whiteSpace:'nowrap', display:'inline-block' }}>
                🔒 Necesită Premium
              </Link>
            </div>
          )}
          {showPreview && <PreviewModal item={item} onClose={() => setShowPreview(false)} />}
        </div>
      </div>
    </div>
  );
}


// ─── Manual inline viewer ─────────────────────────────────────────────────────
function ManualViewer({ item }) {
  const [open, setOpen] = useState(false);
  const { isPremium, user } = useAuth();
  const canAccess = item.is_free || isPremium;

  // Dacă manual_content e un HTML complet, îl deschidem în viewer (ca interactive)
  const isFullHtml = item.manual_content && (
    item.manual_content.trim().startsWith('<!DOCTYPE') ||
    item.manual_content.trim().startsWith('<html')
  );

  if (isFullHtml && canAccess) {
    return (
      <ContentCard
        item={{ ...item, content_type: 'interactive' }}
        isPremium={isPremium}
        user={user}
        progress={null}
        _overrideSrcDoc={item.manual_content}
      />
    );
  }

  return (
    <div style={{ marginBottom: 8 }}>
      <div
        style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '14px 20px', background: '#fff',
          borderRadius: open ? '10px 10px 0 0' : 10,
          border: '1.5px solid #eef0f4',
          borderBottom: open ? 'none' : '1.5px solid #eef0f4',
          cursor: canAccess ? 'pointer' : 'default',
          transition: 'box-shadow 0.2s',
        }}
        onClick={() => canAccess && setOpen(o => !o)}
        onMouseEnter={e => e.currentTarget.style.boxShadow = '0 2px 12px rgba(15,43,68,0.09)'}
        onMouseLeave={e => e.currentTarget.style.boxShadow = 'none'}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 38, height: 38, borderRadius: 8, background: '#e8f5e9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.1rem', opacity: canAccess ? 1 : 0.5 }}>📖</div>
          <div>
            <div style={{ fontWeight: 600, color: canAccess ? 'var(--navy)' : 'var(--text-muted)', fontSize: '0.93rem' }}>{item.title}</div>
            {item.description && <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: 1 }}>{item.description}</div>}
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: '0.7rem', fontWeight: 700, background: item.is_free ? '#e8f5e9' : '#fff3e0', color: item.is_free ? '#2e7d32' : '#e65100' }}>
            {item.is_free ? 'Gratuit' : 'Premium'}
          </span>
          {canAccess
            ? <span style={{ fontSize: '0.9rem', color: 'var(--navy)', fontWeight: 700 }}>{open ? '▲' : '▼'}</span>
            : !user
              ? <Link to="/autentificare" onClick={e => e.stopPropagation()} style={{ padding: '6px 14px', borderRadius: 7, fontWeight: 600, fontSize: '0.82rem', background: '#f0f4f8', color: 'var(--navy)', border: '1.5px solid #dde1e8', textDecoration: 'none' }}>🔒 Autentifică-te</Link>
              : <Link to="/preturi" onClick={e => e.stopPropagation()} style={{ padding: '6px 14px', borderRadius: 7, fontWeight: 600, fontSize: '0.82rem', background: 'var(--gold)', color: 'var(--navy-dark)', textDecoration: 'none' }}>🔒 Necesită Premium</Link>
          }
        </div>
      </div>
      {open && canAccess && (
        <div style={{ padding: '24px 28px', background: '#fff', border: '1.5px solid #eef0f4', borderTop: '1px solid #f0f4f8', borderRadius: '0 0 10px 10px', lineHeight: 1.8, color: 'var(--text)' }}
          dangerouslySetInnerHTML={{ __html: item.manual_content || '<p>Conținut indisponibil.</p>' }}
        />
      )}
    </div>
  );
}

// ─── Componentă principală ────────────────────────────────────────────────────
export default function ContentPage({ category, title, subtitle, breadcrumb, tabs, emptyIcons }) {
  const { user, isPremium, loading: authLoading } = useAuth();
  const location = useLocation();
  const initialTab = (location.state?.returnTab && tabs.some(t => t.id === location.state.returnTab))
    ? location.state.returnTab
    : tabs[0].id;
  const [activeTab, setActiveTab] = useState(initialTab);
  const [items, setItems] = useState([]);
  const [progressMap, setProgressMap] = useState({});
  const [loading, setLoading] = useState(true);
  const scrollRestored = useRef(false);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const { data, error } = await supabase
        .from('content')
        .select('*')
        .eq('category', category)
        .order('sort_order', { ascending: true })
        .order('created_at', { ascending: false });
      if (!error) setItems(data || []);
      setLoading(false);
    }
    load();
  }, [category]);

  // Încarcă progresul pentru exercițiile interactive
  useEffect(() => {
    if (!user || items.length === 0) return;
    const interactiveIds = items
      .filter(i => i.content_type === 'interactive')
      .map(i => i.id);
    if (interactiveIds.length === 0) return;

    supabase
      .from('progress')
      .select('*')
      .eq('user_id', user.id)
      .in('content_id', interactiveIds)
      .then(({ data }) => {
        if (data) {
          const map = {};
          data.forEach(p => { map[p.content_id] = p; });
          setProgressMap(map);
        }
      });
  }, [user, items]);

  // Restaurează poziția după revenirea din PDF/Interactive viewer
  useEffect(() => {
    const cardId = location.state?.scrollToCardId;
    if (!cardId || scrollRestored.current) return;
    if (loading || authLoading) return;
    scrollRestored.current = true;
    const cancel = scrollToCard(cardId, { initialDelay: 50 });
    return () => { scrollRestored.current = false; cancel(); };
  }, [loading, authLoading, location.state]);

  const filtered = items.filter(item => item.content_type === activeTab);

  return (
    <>
      <div className="page-header">
        <div className="container">
          <div className="breadcrumb">
            <Link to="/">Acasă</Link><span>›</span><span>{breadcrumb}</span>
          </div>
          <h1>{title}</h1>
          <p>{subtitle}</p>
        </div>
      </div>

      <div className="content-list">
        <div className="container">
          <div className="tabs">
            {tabs.map(tab => (
              <button
                key={tab.id}
                className={`tab ${activeTab === tab.id ? 'active' : ''}`}
                onClick={() => setActiveTab(tab.id)}
              >
                {tab.label}
                {items.filter(i => i.content_type === tab.id).length > 0 && (
                  <span style={{ marginLeft: 6, background: 'var(--gold)', color: 'var(--navy-dark)', borderRadius: 20, padding: '1px 7px', fontSize: '0.72rem', fontWeight: 700 }}>
                    {items.filter(i => i.content_type === tab.id).length}
                  </span>
                )}
              </button>
            ))}
          </div>

          {loading || authLoading ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}>
              <div className="spinner" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">{emptyIcons?.[activeTab] || '📄'}</div>
              <h3>{tabs.find(t => t.id === activeTab)?.label} – {title}</h3>
              <p>Materialele vor fi adăugate în curând. Revino mai târziu!</p>
            </div>
          ) : (
            <div style={{ marginTop: 8 }}>
              {filtered.map(item =>
                item.content_type === 'manual' && item.manual_content
                  ? <ManualViewer key={item.id} item={item} />
                  : <ContentCard key={item.id} item={item} isPremium={isPremium} user={user} progress={progressMap[item.id]} />
              )}
            </div>
          )}
        </div>
        {/* Secțiune discuții per categorie */}
        <Discussions fixedCategory={category} />
      </div>
    </>
  );
}
